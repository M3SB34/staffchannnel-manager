const { Client, GatewayIntentBits, PermissionsBitField, ActivityType } = require('discord.js');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessages
  ]
});

// =========================
// 🔧 CONFIG
// =========================

// NEED HELP SYSTEM
const NEED_HELP_CHANNEL_ID = "1492983047392329859";
const STAFF_ROLE_ID = "1492974100203835442";
const NEED_HELP_CATEGORY_ID = "1492982637860753498";

// VERIFY SYSTEM
const VERIFY_CHANNEL = "1492982963938398258";
const VERIFY_CATEGORY = "1492982628964503878";
const VERIFY_ROLE = "1492974104653988021";

// =========================
// 🧠 STORAGE
// =========================
const createdChannels = new Set();

// =========================
// 🤖 BOT ACTIVITY (PLAYING ◜零◞)
// =========================
client.once('ready', () => {
  console.log(`✅ Logged in as ${client.user.tag}`);
  
  // Set bot status to idle
  client.user.setStatus('idle'); // Keep idle or change to 'online' if you want
client.user.setActivity('◜零◞', { 
  type: ActivityType.Streaming,
  url: 'https://twitch.tv/discord'  // You need a valid streaming URL
});
  
  console.log(`🎮 Bot status set to IDLE with activity: Playing ◜零◞`);
});

// =========================
// 🎧 VOICE SYSTEM
// =========================
client.on("voiceStateUpdate", async (oldState, newState) => {

  try {
    const member = newState.member;
    const guild = newState.guild;

    // ===================================
    // 🔥 NEED HELP SYSTEM
    // ===================================
    if (newState.channelId === NEED_HELP_CHANNEL_ID) {

      const channel = await guild.channels.create({
        name: `🆘️ • ${member.user.username}Need help`,
        type: 2,
        parent: NEED_HELP_CATEGORY_ID,
        permissionOverwrites: [
          {
            id: guild.id,
            deny: [PermissionsBitField.Flags.Connect]
          },
          {
            id: member.id,
            allow: [
              PermissionsBitField.Flags.Connect,
              PermissionsBitField.Flags.ViewChannel
            ]
          },
          {
            id: STAFF_ROLE_ID,
            allow: [
              PermissionsBitField.Flags.Connect,
              PermissionsBitField.Flags.ViewChannel
            ]
          }
        ]
      }).catch(console.log);

      if (!channel) return;

      createdChannels.add(channel.id);

      await member.voice.setChannel(channel).catch(() => {});

      setTimeout(() => {
        channel.send({
          content: `<@&${STAFF_ROLE_ID}> By : <@${member.id}> Need help staff, please join the channel ◜维◞`,
        }).catch(() => {});
      }, 1000);
    }

    // ===================================
    // 🔥 VERIFY SYSTEM
    // ===================================
    if (newState.channelId === VERIFY_CHANNEL) {

      const channel = await guild.channels.create({
        name: `✅ • ${member.user.username}Want verify`,
        type: 2,
        parent: VERIFY_CATEGORY,
        permissionOverwrites: [
          {
            id: guild.id,
            deny: [PermissionsBitField.Flags.Connect]
          },
          {
            id: member.id,
            allow: [
              PermissionsBitField.Flags.Connect,
              PermissionsBitField.Flags.ViewChannel
            ]
          },
          {
            id: VERIFY_ROLE,
            allow: [
              PermissionsBitField.Flags.Connect,
              PermissionsBitField.Flags.ViewChannel
            ]
          }
        ]
      }).catch(console.log);

      if (!channel) return;

      createdChannels.add(channel.id);

      await member.voice.setChannel(channel).catch(() => {});

      const role = guild.roles.cache.get(VERIFY_ROLE);
      if (role) {
        await member.roles.add(role).catch(console.log);
      }

      setTimeout(() => {
        channel.send({
          content: `<@&${VERIFY_ROLE}> By : <@${member.id}> Come To Verification Channel ◜维◞`,
          allowedMentions: { roles: [VERIFY_ROLE] }
        }).catch(() => {});
      }, 1200);
    }

    // ===================================
    // 🧹 AUTO DELETE EMPTY CHANNELS
    // ===================================
    if (oldState.channelId && createdChannels.has(oldState.channelId)) {

      const channel = oldState.guild.channels.cache.get(oldState.channelId);

      if (channel && channel.members.size === 0) {
        createdChannels.delete(channel.id);
        channel.delete().catch(() => {});
      }
    }

  } catch (err) {
    console.log("Voice system error:", err);
  }

});

// =========================
// 🚀 LOGIN
// =========================
client.login("MTQ5MzA1Mjc0MjkwMDUxOTA3Mw.Gqxwuf.VCbt3oVWAgYsY4tsI4aqPxEPHNa9MVY2Rb6FWk");